import config
import orchestrator
import ingestion_activities
import integration_activities
import db_activities

# Initialize app and have all functions registered
app = config.app

if __name__ == "__main__":
    # Additional startup logic
    pass
